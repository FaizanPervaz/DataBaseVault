﻿using Microsoft.AspNetCore.Mvc;
using _20I0565_Lab2.Models;
using System.Collections.Specialized;

namespace _20I0565_Lab2.Controllers
{
    public class StudentController : Controller
    {
        public static List<Student> students = new List<Student>();
        Student s1= new Student("Faizan","20I0565",4,"A");
        Student s2= new Student("Haider","20I0879",2,"B");
        Student s3= new Student("Umais","20I0854",3.9,"A+");
        Student s4= new Student("Musharib","20I1764",2.7,"I");
        Student s5= new Student("Hanan","20I0743",2.9,"H");
        public StudentController() { }
        

        public IActionResult Index()
        {
            /*students.Add(s1);
            students.Add(s2);
            students.Add(s3);
            students.Add(s4);
            students.Add(s5);*/
            return View(students);
        }

        public IActionResult Create()
        {

            return View();
        }


        [HttpPostAttribute]
        public IActionResult Create(Student student1)
        {
            
            students.Add(student1);

            return RedirectToAction("Index");
        }

        public IActionResult Edit(String rollNum)
        {

            Student s = students.Find((stu) => stu.RollNo == rollNum);

            return View(s);

        }


        [HttpPost]
        public IActionResult Edit(Student st)
        {
        
            Student s = students.Find((stu) => stu.RollNo == st.RollNo);


            s.Name = st.Name;
            s.DBGrade = st.DBGrade;
            s.CGPA = st.CGPA;    
            s.RollNo= st.RollNo;

            return RedirectToAction("Index");
            
        }
    }
}
