﻿using System.Reflection;
using System.Threading;
using System;

namespace _20I0565_Lab2.Models
{
    public class Student
    {
        public string Name { get; set; } = string.Empty;
        public string RollNo { get; set; } = string.Empty;

        public string DBGrade { get; set; } = string.Empty;
        public double CGPA { get; set; }

        public Student() 
        {
        
        }

        public Student(string n, string rn, double cgpa, string db)
        {
            Name= n;
            RollNo= rn;
            CGPA=cgpa;
            DBGrade=db;
        }



    }
}
