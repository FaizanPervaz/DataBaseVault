CREATE DATABASE Lab10
Use Lab10;

CREATE TABLE UserCredentials (
    Username VARCHAR(50) Primary Key ,
    Password VARCHAR(50) Not NUll
);

CREATE TABLE Tasks (
    TaskID INT PRIMARY KEY IDENTITY(1,1),
    TaskName VARCHAR(100),
    DueDate DATE,
    Priority VARCHAR(20),
    CompletionStatus BIT
);

INSERT INTO Tasks (TaskName, DueDate, Priority, CompletionStatus) VALUES
('Finish Report', '2023-11-30', 'High', 0),
('Prepare Presentation', '2023-12-05', 'Medium', 0),
('Review Project Plan', '2023-12-10', 'Low', 0),
('Meeting with Team', '2023-11-25', 'High', 0),
('Research New Technologies', '2023-12-15', 'Medium', 0);



INSERT INTO UserCredentials (Username, Password) VALUES
('user1', 'pass1'),
('user2', 'pass2'),
('user3', 'pass3'),
('user4', 'pass4'),
('user5', 'pass5'),
('user6', 'pass6'),
('user7', 'pass7'),
('user8', 'pass8'),
('user9', 'pass9'),
('user10', 'pass10');


Select * from UserCredentials;
Select * from Tasks;

Update Tasks SET TaskName ='No', DueDate = '2023-11-30', Priority = 'Low' Where TaskID = 1;