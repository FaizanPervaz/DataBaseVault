namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {



        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username1 = username.Text;
            string password1 = password.Text;

            if(username1 == "admin" &&  password1 == "admin")
            {
                MessageBox.Show("Login Successfull");
                Form2 form2 = new Form2();
                form2.Visible = true;
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Wrong Password Or Username");
            }
        }
    }
}